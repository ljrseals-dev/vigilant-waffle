from vme import VME
from vme.metrics import benchmark
for prior in ('procedural','gru','transformer'):
 n=VME(prior=prior,seed=42).generate(160); print(benchmark(n,42,'VME-3.0-'+prior))
