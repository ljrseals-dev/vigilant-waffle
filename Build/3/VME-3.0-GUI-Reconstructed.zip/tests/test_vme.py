from vme import VME
from vme.metrics import benchmark
def test_reproducible():
 a=[n.pitch for n in VME(seed=42).generate(32)]; b=[n.pitch for n in VME(seed=42).generate(32)]; assert a==b
def test_range(): assert all(48<=n.pitch<=84 for n in VME(seed=1).generate(64))
def test_metrics(): assert benchmark(VME(seed=1).generate(32))['mean_interval']>=0
