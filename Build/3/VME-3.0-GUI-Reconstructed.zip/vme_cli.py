import argparse,json
from vme import VME
from vme.rendering import save_wav,save_midi
from vme.metrics import benchmark
def main():
 p=argparse.ArgumentParser();p.add_argument('--prior',default='procedural',choices=['procedural','gru','transformer']);p.add_argument('--temperature',type=float,default=0);p.add_argument('--seed',type=int,default=42);p.add_argument('--notes',type=int,default=160);p.add_argument('--wav');p.add_argument('--midi');p.add_argument('--metrics');a=p.parse_args(); e=VME(a.prior,a.temperature,a.seed); n=e.generate(a.notes)
 if a.wav:save_wav(a.wav,n)
 if a.midi:save_midi(a.midi,n)
 m=benchmark(n,a.seed,f'VME-3.0-{a.prior}'); print(json.dumps(m,indent=2));
 if a.metrics:open(a.metrics,'w').write(json.dumps(m,indent=2))
if __name__=='__main__':main()
