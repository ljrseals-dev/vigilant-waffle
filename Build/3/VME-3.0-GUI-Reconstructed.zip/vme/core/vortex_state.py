from dataclasses import dataclass, field
from typing import List
@dataclass
class VortexState:
    phase: float=0.0; radius: float=0.55; energy: float=0.65; entropy: float=1.0; stall_count: int=0
    orbit_history: List[float]=field(default_factory=list)
