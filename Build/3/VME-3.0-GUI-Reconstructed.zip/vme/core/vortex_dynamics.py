import math, random
from .vortex_state import VortexState
class VortexDynamics:
    def __init__(self,rng=None,low=48,high=84):
        self.rng=rng or random.Random(); self.low=low; self.high=high; self.state=VortexState(); self.angular_speed=.31; self.radius_damping=.92; self.radius_target=.35
    def next_pitch(self):
        s=self.state; s.phase += self.angular_speed+.05*math.sin(s.phase*.37); s.radius=self.radius_damping*s.radius+(1-self.radius_damping)*self.radius_target
        novelty=.5*math.sin(s.phase)+.3*math.sin(2.17*s.phase+1.2)+.2*math.cos(3.7*s.phase)
        s.energy=max(.1,min(1,.82*s.energy+.18*(abs(novelty)+.15))); drift=self.rng.gauss(0,.65+.5*s.energy)
        raw=(self.low+self.high)/2+(self.high-self.low)*.33*novelty+drift; raw=int(round(raw)); s.orbit_history.append(raw); s.orbit_history=s.orbit_history[-32:]
        return max(self.low,min(self.high,raw))
    def observe(self,pitches):
        if len(pitches)<8:return
        u=len(set(pitches[-8:])); self.state.entropy=u/8
        if u<=2:
            self.state.stall_count+=1; self.state.phase+=self.rng.uniform(1.5,3.5); self.state.energy=min(1,self.state.energy+.25)
        else:self.state.stall_count=max(0,self.state.stall_count-1)
