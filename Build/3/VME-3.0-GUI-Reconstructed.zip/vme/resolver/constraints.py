class HardConstraints:
    def __init__(self,low=48,high=84,max_interval=12,max_repeats=2): self.low=low; self.high=high; self.max_interval=max_interval; self.max_repeats=max_repeats
    def valid(self,pitch,prev=None,repeats=0,chord_pc=()):
        if not self.low<=pitch<=self.high:return False
        if prev is not None and abs(pitch-prev)>self.max_interval:return False
        if repeats>=self.max_repeats:return pitch!=prev
        return True
