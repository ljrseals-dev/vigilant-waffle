import math
class ScoreWeights:
    def __init__(self,neural=1.0,vortex=0.8,pst=.5,leap=1.3,repeat=2.0,direction=.35,contour=.35,novelty=.15,harmony=.8):
        self.neural=neural; self.vortex=vortex; self.pst=pst; self.leap=leap; self.repeat=repeat; self.direction=direction; self.contour=contour; self.novelty=novelty; self.harmony=harmony
def softmax(values,temp):
    if temp<=0:return [1 if i==max(range(len(values)),key=values.__getitem__) else 0 for i in range(len(values))]
    m=max(values); e=[math.exp((v-m)/temp) for v in values]; z=sum(e); return [x/z for x in e]
