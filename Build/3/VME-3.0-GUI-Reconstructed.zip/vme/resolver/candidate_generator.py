def generate_candidates(raw_pitch,low=48,high=84,step_range=(-3,-2,-1,0,1,2,3),chord_pc=()):
    c={max(low,min(high,raw_pitch+d)) for d in step_range}|{raw_pitch}
    for pc in chord_pc:
        for octv in range(3,8):
            n=pc+12*octv
            if low<=n<=high:c.add(n)
    return sorted(c)
