import math,random
from .candidate_generator import generate_candidates
from .constraints import HardConstraints
from .scoring import ScoreWeights,softmax
from vme.pst.tonal_context import CHORD_PC,CHORD_ORDER
class DownwashResolver:
    def __init__(self,pst=None,rng=None,config=None):
        self.pst=pst; self.rng=rng or random.Random(); self.weights=config or ScoreWeights(); self.constraints=HardConstraints(); self.current='C'; self.history=[]; self.last_pitch=None; self.last_direction=0; self.repeat_count=0; self.index=0
    def maybe_change_chord(self):
        if self.index and self.index%16==0:self.current=CHORD_ORDER[(CHORD_ORDER.index(self.current)+1)%len(CHORD_ORDER)]
        self.index+=1; return self.current
    def _score(self,cand,raw,prior,vortex_score=0):
        w=self.weights; leap=abs(cand-self.last_pitch) if self.last_pitch is not None else 0; leap_cost=max(0,leap-3)
        pcs=CHORD_PC[self.current]; hd=min((cand-pc)%12 for pc in pcs); hd=min(hd,12-hd)
        rep=1 if cand==self.last_pitch else 0; direction=0
        if self.last_pitch is not None and self.last_direction:
            nd=1 if cand>self.last_pitch else -1 if cand<self.last_pitch else 0; direction=1 if nd and nd!=self.last_direction else 0
        neural=prior.get(cand,0); pst_score=(self.pst.distribution(self.history).get(cand,0) if self.pst else 0)
        contour=-abs((cand-raw)); novelty=0 if cand in self.history[-8:] else 1
        return w.neural*math.log(neural+1e-9)+w.vortex*vortex_score-w.leap*leap_cost-w.repeat*rep-w.direction*direction-w.harmony*hd+w.pst*pst_score+w.contour*contour+w.novelty*novelty
    def _forced_step(self):
        base=self.last_pitch or 60
        return max(self.constraints.low,min(self.constraints.high,base+ (2 if self.last_direction<=0 else -2)))
    def resolve(self,raw_pitch,temperature=0,prior=None,vortex_score=0):
        prior=prior or {}; candidates=generate_candidates(raw_pitch,self.constraints.low,self.constraints.high,chord_pc=CHORD_PC[self.current]); candidates=[c for c in candidates if self.constraints.valid(c,self.last_pitch,self.repeat_count)]
        if not candidates:candidates=[self._forced_step()]
        scores=[self._score(c,raw_pitch,prior,vortex_score) for c in candidates]
        if temperature<=0:selected=candidates[max(range(len(candidates)),key=scores.__getitem__)]
        else:selected=self.rng.choices(candidates,weights=softmax(scores,temperature),k=1)[0]
        if selected==self.last_pitch:self.repeat_count+=1
        else:self.repeat_count=0
        if self.repeat_count>=self.constraints.max_repeats:selected=self._forced_step();self.repeat_count=0
        if self.last_pitch is not None and selected!=self.last_pitch:self.last_direction=1 if selected>self.last_pitch else -1
        self.last_pitch=selected; self.history.append(selected); return selected
