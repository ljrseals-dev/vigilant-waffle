def train(*args,**kwargs): raise NotImplementedError('Training backend is intentionally optional; provide a PyTorch model/checkpoint to the prior.')
