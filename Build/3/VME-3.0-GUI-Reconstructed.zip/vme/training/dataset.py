class SequenceDataset:
    def __init__(self,sequences): self.sequences=sequences
    def __len__(self): return len(self.sequences)
