PITCHES=list(range(128))
def encode_pitch(p): return int(p)
def decode_pitch(i): return int(i)
