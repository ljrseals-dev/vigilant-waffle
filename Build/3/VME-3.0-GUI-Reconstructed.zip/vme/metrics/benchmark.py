import math,collections
BASELINE={'stepwise_motion':.4654,'repeated_notes':0.0,'key_correlation':.868,'mean_interval':2.33}
def entropy(xs):
 c=collections.Counter(xs); n=len(xs) or 1; return -sum((v/n)*math.log2(v/n) for v in c.values())
def benchmark(notes,seed=None,engine='VME-3.0'):
 p=[n.pitch for n in notes]; ints=[abs(b-a) for a,b in zip(p,p[1:])]; repeats=sum(a==b for a,b in zip(p,p[1:]))/max(1,len(ints)); steps=sum(i<=2 for i in ints)/max(1,len(ints)); pcs=[x%12 for x in p]; center=sum(pcs)/max(1,len(pcs)); key_corr=max((sum(math.cos(2*math.pi*(x-k)/12) for x in pcs)/len(pcs) for k in range(12)),default=0)
 return {'engine':engine,'seed':seed,'stepwise_motion':steps,'repeated_notes':repeats,'key_correlation':key_corr,'mean_interval':sum(ints)/max(1,len(ints)),'pitch_entropy':entropy(p),'rhythmic_entropy':entropy([round(n.duration,3) for n in notes]),'phrase_repetition':0.0,'novelty':len(set(p))/max(1,len(p)),'cadence_rate':sum(1 for i in ints if i in (0,1,2,7,12))/max(1,len(ints))}
