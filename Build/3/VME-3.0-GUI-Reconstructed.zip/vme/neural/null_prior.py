class NullPrior:
    def logits(self,history,context): return {}
