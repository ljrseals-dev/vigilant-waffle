from abc import ABC,abstractmethod
class SequencePrior(ABC):
    @abstractmethod
    def logits(self,history,context): raise NotImplementedError
