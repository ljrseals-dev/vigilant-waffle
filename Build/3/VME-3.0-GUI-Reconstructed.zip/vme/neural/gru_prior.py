class GRUPrior:
    """Optional PyTorch prior. Without a checkpoint it returns a neutral distribution."""
    def __init__(self,model=None): self.model=model
    def logits(self,history,context):
        if self.model is None:return {}
        return self.model.predict_logits(history,context)
