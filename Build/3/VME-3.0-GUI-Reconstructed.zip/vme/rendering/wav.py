import math,wave,struct
def save_wav(path,notes,sr=44100):
    total=int((notes[-1].time+notes[-1].duration)*sr) if notes else 0; buf=[0.0]*total
    for n in notes:
        a=int(n.time*sr); b=min(total,int((n.time+n.duration)*sr)); freq=440*2**((n.pitch-69)/12); amp=n.velocity/127*.18
        for i in range(a,b):
            x=(i-a)/sr; env=min(1,x/.01,(n.duration-x)/.03); buf[i]+=amp*max(0,env)*math.sin(2*math.pi*freq*x)
    with wave.open(path,'wb') as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(sr); w.writeframes(b''.join(struct.pack('<h',max(-32767,min(32767,int(x*32767)))) for x in buf))
