import struct
def _vlq(n):
 b=[n&127]; n>>=7
 while n:b.append((n&127)|128);n>>=7
 return bytes(reversed(b))
def save_midi(path,notes,ppq=480):
 data=bytearray(); last=0
 for n in notes:
  on=round(n.time*2*ppq); off=round((n.time+n.duration)*2*ppq); data+=_vlq(on-last)+bytes([0x90,n.pitch,n.velocity]); data+=_vlq(off-on)+bytes([0x80,n.pitch,0]); last=off
 track=_vlq(len(data)+4)+data+bytes([0,0xff,0x2f,0])
 with open(path,'wb') as f:f.write(b'MThd'+struct.pack('>IHHH',6,0,1,ppq)+b'MTrk'+track)
