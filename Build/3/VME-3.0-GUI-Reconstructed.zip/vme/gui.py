"""Tkinter desktop interface for the reconstructed VME 3.0 engine."""
from __future__ import annotations

import json
import os
import platform
import subprocess
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk

from . import VME
from .metrics import benchmark
from .rendering.wav import save_wav

try:
    import pygame
except ImportError:  # optional playback dependency
    pygame = None


class VMEGUI:
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title("Vortex Music Engine 3.0")
        self.root.geometry("700x650")
        self.root.minsize(620, 560)

        self.seed = tk.IntVar(value=42)
        self.temperature = tk.DoubleVar(value=0.0)
        self.notes_count = tk.IntVar(value=160)
        self.tempo = tk.DoubleVar(value=110.0)
        self.prior = tk.StringVar(value="procedural")
        self.output_path = tk.StringVar(value=str(Path.cwd() / "vme3_output.wav"))
        self.status = tk.StringVar(value="Ready")
        self.metrics = {}
        self.last_notes = []
        self.generating = False

        self._build()

    def _build(self):
        main = ttk.Frame(self.root, padding=12)
        main.pack(fill="both", expand=True)

        params = ttk.LabelFrame(main, text="Generation", padding=10)
        params.pack(fill="x")

        fields = [
            ("Seed", self.seed),
            ("Temperature", self.temperature),
            ("Notes", self.notes_count),
            ("Tempo (BPM)", self.tempo),
        ]
        for i, (label, variable) in enumerate(fields):
            row, col = divmod(i, 2)
            ttk.Label(params, text=label).grid(row=row, column=col * 2, sticky="w", padx=(0, 6), pady=5)
            ttk.Entry(params, textvariable=variable, width=12).grid(row=row, column=col * 2 + 1, sticky="ew", padx=(0, 18), pady=5)

        ttk.Label(params, text="Prior").grid(row=2, column=0, sticky="w", padx=(0, 6), pady=5)
        ttk.Combobox(
            params,
            textvariable=self.prior,
            values=("procedural", "gru", "transformer"),
            state="readonly",
            width=14,
        ).grid(row=2, column=1, sticky="ew", padx=(0, 18), pady=5)
        params.columnconfigure(1, weight=1)
        params.columnconfigure(3, weight=1)

        output = ttk.LabelFrame(main, text="Output", padding=10)
        output.pack(fill="x", pady=(10, 0))
        ttk.Entry(output, textvariable=self.output_path).pack(side="left", fill="x", expand=True)
        ttk.Button(output, text="Browse…", command=self._browse).pack(side="left", padx=(8, 0))

        buttons = ttk.Frame(main)
        buttons.pack(fill="x", pady=10)
        self.generate_button = ttk.Button(buttons, text="Generate", command=self._generate)
        self.generate_button.pack(side="left", padx=(0, 6))
        self.play_button = ttk.Button(buttons, text="Play", command=self._play, state="disabled")
        self.play_button.pack(side="left", padx=6)
        ttk.Button(buttons, text="Save Metrics", command=self._save_metrics).pack(side="left", padx=6)
        ttk.Button(buttons, text="Random Seed", command=self._random_seed).pack(side="right")

        metrics_frame = ttk.LabelFrame(main, text="Benchmark Metrics", padding=10)
        metrics_frame.pack(fill="both", expand=True)
        self.metrics_text = tk.Text(metrics_frame, height=16, width=70, state="disabled", wrap="none")
        self.metrics_text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(metrics_frame, orient="vertical", command=self.metrics_text.yview)
        scroll.pack(side="right", fill="y")
        self.metrics_text.configure(yscrollcommand=scroll.set)

        ttk.Label(main, textvariable=self.status, relief="sunken", anchor="w").pack(fill="x", pady=(8, 0))

    def _browse(self):
        path = filedialog.asksaveasfilename(
            title="Save VME WAV",
            defaultextension=".wav",
            filetypes=[("WAV audio", "*.wav")],
        )
        if path:
            self.output_path.set(path)

    def _random_seed(self):
        import secrets
        self.seed.set(secrets.randbelow(2**31))

    def _set_metrics(self, data):
        self.metrics = data
        lines = []
        for key, value in data.items():
            if isinstance(value, float):
                lines.append(f"{key:22s}: {value:.4f}")
            else:
                lines.append(f"{key:22s}: {value}")
        self.metrics_text.configure(state="normal")
        self.metrics_text.delete("1.0", "end")
        self.metrics_text.insert("1.0", "\n".join(lines))
        self.metrics_text.configure(state="disabled")

    def _generate(self):
        if self.generating:
            return
        try:
            seed = int(self.seed.get())
            temperature = float(self.temperature.get())
            count = int(self.notes_count.get())
            tempo = float(self.tempo.get())
            if count < 1 or not 20 <= tempo <= 400 or temperature < 0:
                raise ValueError("Notes must be >= 1, tempo must be 20–400 BPM, and temperature must be >= 0.")
            if not self.output_path.get().lower().endswith(".wav"):
                raise ValueError("Output file must have a .wav extension.")
        except (TypeError, ValueError) as exc:
            messagebox.showerror("Invalid parameters", str(exc))
            return

        self.generating = True
        self.generate_button.configure(state="disabled")
        self.play_button.configure(state="disabled")
        self.status.set("Generating…")

        def worker():
            try:
                engine = VME(prior=self.prior.get(), temperature=temperature, seed=seed)
                notes = engine.generate(count, tempo=tempo)
                path = Path(self.output_path.get()).expanduser()
                path.parent.mkdir(parents=True, exist_ok=True)
                save_wav(str(path), notes, sr=44100)
                bench = benchmark(notes, seed=seed, engine=f"VME-3.0-{self.prior.get()}")
                self.root.after(0, lambda: self._generation_complete(notes, bench, str(path)))
            except Exception as exc:
                self.root.after(0, lambda e=exc: self._generation_failed(e))

        threading.Thread(target=worker, daemon=True).start()

    def _generation_complete(self, notes, bench, path):
        self.last_notes = notes
        self._set_metrics(bench)
        self.generating = False
        self.generate_button.configure(state="normal")
        self.play_button.configure(state="normal")
        self.status.set(f"Generated {len(notes)} notes → {path}")

    def _generation_failed(self, exc):
        self.generating = False
        self.generate_button.configure(state="normal")
        self.status.set("Generation failed.")
        messagebox.showerror("Generation error", str(exc))

    def _play(self):
        path = Path(self.output_path.get()).expanduser()
        if not path.exists():
            messagebox.showerror("Playback", "Generate a WAV file first.")
            return
        if pygame is not None:
            try:
                if not pygame.mixer.get_init():
                    pygame.mixer.init()
                pygame.mixer.music.load(str(path))
                pygame.mixer.music.play()
                self.status.set("Playing…")
                return
            except Exception as exc:
                self.status.set(f"pygame playback unavailable: {exc}")

        try:
            system = platform.system()
            if system == "Windows":
                os.startfile(str(path))  # type: ignore[attr-defined]
            elif system == "Darwin":
                subprocess.Popen(["open", str(path)])
            else:
                subprocess.Popen(["xdg-open", str(path)])
            self.status.set("Opened audio with the system player.")
        except Exception as exc:
            messagebox.showerror("Playback", f"Could not open WAV: {exc}")

    def _save_metrics(self):
        if not self.metrics:
            messagebox.showerror("Metrics", "Generate a piece before saving metrics.")
            return
        path = filedialog.asksaveasfilename(
            title="Save VME benchmark",
            defaultextension=".json",
            filetypes=[("JSON", "*.json")],
        )
        if path:
            with open(path, "w", encoding="utf-8") as fh:
                json.dump(self.metrics, fh, indent=2)
                fh.write("\n")
            self.status.set(f"Metrics saved → {path}")


def main():
    root = tk.Tk()
    VMEGUI(root)
    root.mainloop()


if __name__ == "__main__":
    main()
