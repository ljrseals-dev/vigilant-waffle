from collections import defaultdict,Counter
class HarmonicMemory:
    def __init__(self,max_order=3,min_count=1): self.max_order=max_order; self.min_count=min_count; self.pst=defaultdict(Counter); self.all_symbols=[]
    def train(self,sequences):
        seen=set()
        for seq in sequences:
            for i,s in enumerate(seq):
                seen.add(s)
                for o in range(1,min(self.max_order,i)+1): self.pst[tuple(seq[i-o:i])][s]+=1
        self.all_symbols=sorted(seen)
    def distribution(self,history):
        for o in range(min(self.max_order,len(history)),0,-1):
            c=self.pst.get(tuple(history[-o:]))
            if c and sum(c.values())>=self.min_count:
                z=sum(c.values()); return {k:v/z for k,v in c.items()}
        return {s:1/len(self.all_symbols) for s in self.all_symbols} if self.all_symbols else {}
