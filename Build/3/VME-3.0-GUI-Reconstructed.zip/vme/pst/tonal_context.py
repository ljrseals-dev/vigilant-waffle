CHORD_PC={'C':(0,4,7),'Dm':(2,5,9),'Em':(4,7,11),'F':(5,9,0),'G':(7,11,2),'Am':(9,0,4)}
CHORD_ORDER=('C','Am','F','G','Em','Dm')
def pitch_classes(chord): return CHORD_PC[chord]
