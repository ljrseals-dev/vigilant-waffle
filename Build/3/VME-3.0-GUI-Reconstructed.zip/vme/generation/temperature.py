def clamp_temperature(t): return max(0.0,float(t))
