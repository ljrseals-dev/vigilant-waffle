import random
def seed_everything(seed): random.seed(seed)
