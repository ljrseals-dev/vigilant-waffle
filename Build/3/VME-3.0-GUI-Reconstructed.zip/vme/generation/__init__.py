from .generator import Generator,NoteEvent
