from collections import defaultdict
from dataclasses import dataclass
import random
from typing import Dict, Iterable, List, Sequence, Tuple
from .theory import CHORD_PC

class PredictionSuffixTree:
    """Variable-order Markov model with deterministic insertion order."""
    def __init__(self, max_order: int = 3, min_count: int = 1):
        if max_order < 1 or min_count < 1: raise ValueError("max_order and min_count must be positive")
        self.max_order=max_order; self.min_count=min_count; self.pst: Dict[Tuple[str,...],Dict[str,int]]=defaultdict(dict); self.all_symbols=[]; self._symbol_set=set()
    def train(self,sequences:Iterable[Sequence[str]]) -> None:
        for seq in sequences:
            for i in range(1,len(seq)):
                for order in range(1,min(self.max_order,i)+1):
                    ctx=tuple(seq[i-order:i]); nxt=seq[i]; bucket=self.pst[ctx]; bucket[nxt]=bucket.get(nxt,0)+1
                    for sym in (nxt,seq[i-1]):
                        if sym not in self._symbol_set: self._symbol_set.add(sym); self.all_symbols.append(sym)
    def sample(self,history:Sequence[str],rng:random.Random)->str:
        for order in range(min(self.max_order,len(history)),0,-1):
            counts=self.pst.get(tuple(history[-order:]))
            if counts and sum(counts.values())>=self.min_count:
                symbols=list(counts); return rng.choices(symbols,weights=[counts[s] for s in symbols],k=1)[0]
        return rng.choice(self.all_symbols) if self.all_symbols else "C"

def default_pst():
    corpus=[["C","G","Am","F","C","G","C"],["C","Am","F","G","C"],["Am","F","C","G","Am"],["F","C","G","Am","F"],["C","F","G","C"],["G","C","Am","F","G"],["Dm","G","C","Am","Dm"],["Em","Am","F","C","Em"],["C","G","C","F","G","C"],["Am","Dm","G","C"]]
    p=PredictionSuffixTree(3,1); p.train(corpus); return p

@dataclass
class ResolverConfig:
    alpha:float=1.05; beta:float=1.8; gamma:float=2.8; delta:float=.3; soft_leap:float=2.6; max_repeats:int=1

class DownwashResolver:
    def __init__(self,config=None,pst=None,rng=None):
        self.cfg=config or ResolverConfig(); self.pst=pst or default_pst(); self.rng=rng or random.Random(); self.current="C"; self.history=["C"]
        self.last_pitch=None; self.last_direction=0; self.repeat_count=0
        self.rhythms=((4,4,4,4),(2,2,4,4),(4,2,2,4),(8,4,2,2),(3,3,2,4)); self.pattern=self.rng.choice(self.rhythms); self.pattern_idx=0; self.chord_step=0
    def maybe_change_chord(self):
        self.chord_step+=1
        if self.chord_step>=self.pattern[self.pattern_idx]:
            self.chord_step=0; self.current=self.pst.sample(self.history,self.rng); self.history=(self.history+[self.current])[-self.pst.max_order:]; self.pattern_idx=(self.pattern_idx+1)%len(self.pattern)
            if self.rng.random()<.12: self.pattern=self.rng.choice(self.rhythms); self.pattern_idx=0
        return self.current
    def _cost(self,cand):
        leap=0 if self.last_pitch is None else abs(cand-self.last_pitch); leap_cost=max(0,leap-self.cfg.soft_leap)*1.3
        chord_dist=min(min((cand-pc)%12,(pc-cand)%12) for pc in CHORD_PC[self.current])
        repeat=1 if self.last_pitch is not None and cand==self.last_pitch else 0; direction=0
        if self.last_pitch is not None and self.last_direction:
            nd=1 if cand>self.last_pitch else -1 if cand<self.last_pitch else 0
            if nd and nd!=self.last_direction: direction=self.cfg.delta
        return self.cfg.alpha*leap_cost+self.cfg.beta*chord_dist+self.cfg.gamma*repeat+direction
    def _forced_step(self):
        if self.last_pitch is None:return 60
        pcs=CHORD_PC[self.current]; candidates=[n for n in range(48,85) if n%12 in pcs and 1<=abs(n-self.last_pitch)<=3]
        if not candidates: candidates=[n for n in range(max(48,self.last_pitch-3),min(84,self.last_pitch+3)+1) if n!=self.last_pitch]
        return self.rng.choice(candidates)
    def resolve(self,raw_pitch):
        raw_pitch=int(max(48,min(84,raw_pitch))); candidates={raw_pitch,*[raw_pitch+d for d in (-3,-2,-1,1,2,3)]}
        candidates.update(n for n in range(48,85) if n%12 in CHORD_PC[self.current] and abs(n-raw_pitch)<=6)
        selected=min(candidates,key=lambda x:(self._cost(x),abs(x-raw_pitch),x)); previous=self.last_pitch
        if previous is not None and selected==previous:
            self.repeat_count+=1
            if self.repeat_count>=self.cfg.max_repeats: selected=self._forced_step(); self.repeat_count=0
        else:self.repeat_count=0
        if previous is not None and selected!=previous:self.last_direction=1 if selected>previous else -1
        self.last_pitch=selected; return selected
