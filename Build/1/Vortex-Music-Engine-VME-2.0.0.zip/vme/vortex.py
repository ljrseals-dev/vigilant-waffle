import math
from dataclasses import dataclass
import random

@dataclass
class VortexState:
    phase: float = 0.0
    radius: float = 0.55
    energy: float = 0.65
    entropy: float = 1.0
    stall_count: int = 0

class VortexGenerator:
    """Latent orbit mapped to pitch with entropy-based anti-stall dynamics."""
    def __init__(self, rng, low=58, high=76):
        self.rng=rng; self.low=low; self.high=high; self.state=VortexState()
    def next_pitch(self):
        s=self.state
        angular=0.31 + 0.17*math.sin(s.phase*0.37)
        s.phase += angular
        novelty=0.5*math.sin(s.phase)+0.3*math.sin(2.17*s.phase+1.2)+0.2*math.cos(3.7*s.phase)
        drift=self.rng.gauss(0,0.65 + 0.5*s.energy)
        center=(self.low+self.high)/2
        raw=int(round(center + (self.high-self.low)*0.33*novelty + drift))
        raw=max(self.low,min(self.high,raw))
        s.energy=max(0.1,min(1.0,0.82*s.energy+0.18*(abs(novelty)+0.15)))
        s.radius=0.92*s.radius+0.08*(0.35+0.6*abs(novelty))
        return raw
    def observe(self, pitches):
        if len(pitches)<8: return
        recent=pitches[-8:]; unique=len(set(recent)); s=self.state
        s.entropy=unique/8.0
        if unique<=2:
            s.stall_count += 1
            s.phase += self.rng.uniform(1.5,3.5)
            s.energy=min(1.0,s.energy+0.25)
        else: s.stall_count=max(0,s.stall_count-1)
