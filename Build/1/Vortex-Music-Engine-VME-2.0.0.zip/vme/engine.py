from dataclasses import dataclass
import random
import numpy as np
from scipy.io import wavfile
from .models import DownwashResolver, ResolverConfig
from .synthesis import NeuralTimbreSynthesizer
from .theory import NoteEvent, key_correlation
from .vortex import VortexGenerator

@dataclass
class GenerationResult:
    notes: list
    audio: np.ndarray
    sample_rate: int
    metrics: dict

class VortexMusicEngine:
    def __init__(self, seed=42, sample_rate=44100, tempo=110, resolver_config=None):
        self.seed=seed; self.sr=sample_rate; self.tempo=tempo
        self.rng=random.Random(seed); self.np_rng=np.random.default_rng(seed)
        self.vortex=VortexGenerator(self.rng); self.resolver=DownwashResolver(resolver_config or ResolverConfig(), rng=self.rng); self.synth=NeuralTimbreSynthesizer()
    def generate(self, n_notes=160):
        beat_sec=60.0/self.tempo; notes=[]; audio=[]; pitches=[]; onset=0.0
        last_raw=None
        for i in range(n_notes):
            raw=self.vortex.next_pitch(); last_raw=raw
            chord=self.resolver.maybe_change_chord(); pitch=self.resolver.resolve(raw); pitches.append(pitch); self.vortex.observe(pitches)
            pattern=self.resolver.pattern; dur_beats=(pattern[self.resolver.pattern_idx-1] if pattern else 4)*0.22
            dur_sec=max(0.08,min(0.9, dur_beats*beat_sec)); velocity=int(72+18*(0.5+0.5*np.sin(i*0.37)))
            notes.append(NoteEvent(pitch,velocity,dur_beats,chord,onset)); audio.append(self.synth.synthesize(pitch,velocity,dur_sec,self.sr)); audio.append(np.zeros(int(.035*self.sr))); onset += dur_beats
        full=np.concatenate(audio) if audio else np.zeros(0); peak=np.max(np.abs(full)) if len(full) else 0
        if peak: full=full/peak*.82
        intervals=[abs(pitches[i+1]-pitches[i]) for i in range(len(pitches)-1)]
        metrics={'stepwise_pct':100*sum(x<=2 for x in intervals)/len(intervals) if intervals else 0,'repeat_pct':100*sum(x==0 for x in intervals)/len(intervals) if intervals else 0,'mean_interval':float(np.mean(intervals)) if intervals else 0,'key_correlation':key_correlation(pitches),'unique_pitch_count':len(set(pitches)),'duration_seconds':len(full)/self.sr}
        return GenerationResult(notes,full.astype(np.float32),self.sr,metrics)
    @staticmethod
    def save_wav(path,result):
        audio=np.clip(result.audio,-1,1); wavfile.write(path,result.sample_rate,(audio*32767).astype(np.int16))
