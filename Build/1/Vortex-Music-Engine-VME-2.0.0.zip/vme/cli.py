import argparse, json
from .engine import VortexMusicEngine

def main():
    p=argparse.ArgumentParser(description='Vortex Music Engine 2.0')
    p.add_argument('--seed',type=int,default=42); p.add_argument('--notes',type=int,default=160); p.add_argument('--tempo',type=float,default=110); p.add_argument('--sample-rate',type=int,default=44100); p.add_argument('--output',default='final_vortex.wav'); p.add_argument('--metrics',default=None)
    a=p.parse_args(); engine=VortexMusicEngine(a.seed,a.sample_rate,a.tempo); result=engine.generate(a.notes); engine.save_wav(a.output,result)
    print(json.dumps(result.metrics,indent=2))
    if a.metrics: open(a.metrics,'w',encoding='utf-8').write(json.dumps(result.metrics,indent=2))
if __name__=='__main__': main()
