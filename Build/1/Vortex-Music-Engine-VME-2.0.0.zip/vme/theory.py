from dataclasses import dataclass
from typing import Dict, Tuple
import math

CHORDS: Dict[str, Tuple[int, int, int]] = {
    "C": (60, 64, 67), "Dm": (62, 65, 69), "Em": (64, 67, 71),
    "F": (65, 69, 72), "G": (67, 71, 74), "Am": (69, 72, 76),
}
CHORD_PC = {k: tuple(n % 12 for n in v) for k, v in CHORDS.items()}
MAJOR_PROFILE = (6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88)

@dataclass(frozen=True)
class NoteEvent:
    pitch: int
    velocity: int
    duration_beats: float
    chord: str
    onset_beats: float


def midi_to_hz(note: float) -> float:
    return 440.0 * (2.0 ** ((note - 69.0) / 12.0))


def nearest_chord_distance(pitch: int, chord: str) -> int:
    pcs = CHORD_PC[chord]
    return min(min((pitch - pc) % 12, (pc - pitch) % 12) for pc in pcs)


def nearest_chord_tone(pitch: int, chord: str, low: int = 48, high: int = 84) -> int:
    candidates = [pc + 12 * octv for pc in CHORD_PC[chord] for octv in range(3, 9)]
    candidates = [n for n in candidates if low <= n <= high]
    return min(candidates, key=lambda n: (abs(n-pitch), abs(n-60)))


def key_correlation(pitches) -> float:
    if not pitches:
        return 0.0
    hist = [0.0] * 12
    for p in pitches:
        hist[p % 12] += 1.0
    total = sum(hist)
    hist = [x / total for x in hist]
    mx = sum(hist) / 12.0
    mp = sum(MAJOR_PROFILE) / 12.0
    num = sum((a-mx)*(b-mp) for a,b in zip(hist, MAJOR_PROFILE))
    den = math.sqrt(sum((a-mx)**2 for a in hist) * sum((b-mp)**2 for b in MAJOR_PROFILE))
    return num / den if den else 0.0
