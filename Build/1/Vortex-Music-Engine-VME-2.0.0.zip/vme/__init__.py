"""Vortex Music Engine: deterministic hybrid generative music."""
from .engine import VortexMusicEngine, GenerationResult
__version__ = "2.0.0"
__all__ = ["VortexMusicEngine", "GenerationResult"]
