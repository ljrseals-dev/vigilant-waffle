import math
import numpy as np
from .theory import midi_to_hz

class NeuralTimbreSynthesizer:
    """Dependency-light harmonic model; no fake training pass is performed."""
    def __init__(self, harmonics=16): self.harmonics = harmonics
    def _amps(self, pitch, velocity):
        brightness = max(0.15, min(1.25, 0.35 + velocity/127.0 - max(0,pitch-60)*0.008))
        return np.array([(1.0/(i+1))**0.82 * brightness**(0.45 + i/self.harmonics*0.3) for i in range(self.harmonics)], dtype=np.float64)
    @staticmethod
    def adsr(n, sr, attack=.02, decay=.1, sustain=.70, release=.15):
        if n <= 0: return np.empty(0)
        a=min(int(attack*sr),n); d=min(int(decay*sr),n-a); r=min(int(release*sr),n-a-d); s=max(0,n-a-d-r)
        e=np.empty(n); pos=0
        if a: e[pos:pos+a]=np.linspace(0,1,a,endpoint=False); pos+=a
        if d: e[pos:pos+d]=np.linspace(1,sustain,d,endpoint=False); pos+=d
        if s: e[pos:pos+s]=sustain; pos+=s
        if r: e[pos:pos+r]=np.linspace(sustain,0,r,endpoint=True)
        return e
    def synthesize(self, pitch, velocity, duration, sr=44100):
        n=max(1,int(round(duration*sr))); t=np.arange(n)/sr; f0=midi_to_hz(pitch); amps=self._amps(pitch,velocity)
        wave=np.zeros(n)
        for i,a in enumerate(amps,1):
            wave += a*np.sin(2*np.pi*f0*i*t)
        wave *= self.adsr(n,sr)
        peak=np.max(np.abs(wave)); return (wave/peak*0.75) if peak else wave
