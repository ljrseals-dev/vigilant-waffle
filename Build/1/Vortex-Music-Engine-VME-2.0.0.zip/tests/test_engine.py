import numpy as np
from vme.engine import VortexMusicEngine
from vme.models import PredictionSuffixTree

def test_reproducible():
    a=VortexMusicEngine(7).generate(32); b=VortexMusicEngine(7).generate(32)
    assert np.array_equal(a.audio,b.audio); assert [n.pitch for n in a.notes]==[n.pitch for n in b.notes]

def test_bounds_and_audio():
    r=VortexMusicEngine(1).generate(20)
    assert all(48<=n.pitch<=84 for n in r.notes); assert np.max(np.abs(r.audio))<=.821

def test_pst():
    p=PredictionSuffixTree(2,1); p.train([['C','G','Am'],['C','G','F']])
    assert p.sample(['C'],__import__('random').Random(1)) in {'G','C','F','Am'}
