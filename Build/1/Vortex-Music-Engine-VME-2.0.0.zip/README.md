# Vortex Music Engine (VME) 2.0.0

A cleaned, runnable implementation of the VME research prototype. The original archive was a **research/code dump rather than a runnable package**: two primary `.py` files contained prose and Markdown fences, several v7 files were competing tuning experiments, the advertised `vme_hybrid.py` entry point was absent, and the VAE was trained on synthetic random data and then described as a production component.

## What was rebuilt

- **VortexGenerator**: deterministic latent orbit with energy/radius dynamics and an entropy/stall response.
- **PredictionSuffixTree**: variable-order chord model with explicit RNG injection.
- **DownwashResolver**: multi-objective melodic resolver with leap, harmony, repetition, and contour terms.
- **NeuralTimbreSynthesizer**: dependency-light harmonic/ADSR renderer. The misleading synthetic neural training loop was removed; the original model was effectively learning a hand-written formula anyway.
- **Real engine API**: `VortexMusicEngine.generate()` returns notes, audio, sample rate, and metrics.
- **CLI**: `vme --seed 42 --notes 160 --output final_vortex.wav`.
- **Tests**: deterministic generation, pitch bounds/audio safety, and PST behavior.
- **Packaging**: `pyproject.toml`, requirements, and clean module layout.

## Install

```bash
python -m venv .venv
# Linux/macOS
source .venv/bin/activate
# Windows PowerShell
# .venv\\Scripts\\Activate.ps1
pip install -r requirements.txt
pip install -e .
```

## Generate

```bash
python -m vme.cli --seed 42 --notes 160 --tempo 110 --output final_vortex.wav --metrics metrics.json
```

## Test

```bash
pytest -q
```

## Important technical corrections

1. **The old `Source/Vortex_therealla.py` was not executable Python.** It contained conversational prose, Markdown fences, and a placeholder comment inside the source file.
2. **The advertised VAE was not actually a useful learned melody model.** It was trained on procedurally generated sparse pitch matrices and, in the main path, the final hybrid generator used a constrained random walk instead of the VAE. VME 2.0 therefore makes the vortex generator explicit rather than pretending that the VAE supplies learned musical structure.
3. **The old chord-distance implementation was octave-limited and inconsistent.** The new resolver evaluates pitch classes and bounded MIDI candidates directly.
4. **The old forced-step direction assignment had a state bug**: it assigned `last_pitch = forced` and then compared `forced` to `last_pitch`, which always produced zero/incorrect direction state. VME 2.0 updates direction against the previous pitch before committing state.
5. **Randomness is dependency-injected** into PST/resolver/vortex, making seeded runs reproducible.
6. **The original README promised 60 seconds**, but 160 notes at 110 BPM with the actual note-duration logic did not guarantee that. VME reports actual duration rather than making a false promise.

## Architecture

```text
Vortex latent orbit + stall/entropy feedback
                 |
                 v
          raw pitch candidate
                 |
                 v
     Prediction Suffix Tree (chords)
                 |
                 v
          Downwash Resolver
     leap + chord + repeat + contour
                 |
                 v
       NoteEvent / musical timeline
                 |
                 v
     harmonic renderer + ADSR
                 |
                 v
              WAV + metrics
```

## Research roadmap

The strongest next upgrade is **not** to re-add the old VAE unchanged. For a genuinely learned system, train a sequence model (LSTM/GRU/Transformer) on an actual symbolic corpus and make its output one candidate stream alongside the vortex stream. Keep PST + resolver as an interpretable constraint layer. A second-stage DDSP/neural-vocoder timbre model can replace the harmonic renderer once real instrument training data is available.
