from vme import VortexMusicEngine
engine=VortexMusicEngine(seed=42)
result=engine.generate(160)
engine.save_wav('final_vortex.wav', result)
print(result.metrics)
