# VME audit

## Original archive findings

| Area | Finding | Severity | Resolution |
|---|---|---:|---|
| Entry point | README references `vme_hybrid.py`, but archive has no such file | Critical | Added `vme.cli` and package entry point |
| Syntax | `Vortex_therealla.py` begins with prose/Markdown, not a Python module | Critical | Reimplemented into modules |
| Syntax | `Research/NeuralTimbreSynthesizer.py` also begins/ends with prose and Markdown fences | Critical | Reimplemented renderer |
| Architecture | VAE described as raw generator, but main hybrid path actually uses a random walk | High | Explicit VortexGenerator replaces hidden fallback |
| ML validity | Synthetic MLP learns a hand-authored harmonic formula | High | Removed pseudo-learning loop |
| PST | Competing v7 files contain multiple tuning passes | Medium | Consolidated into one ResolverConfig |
| Resolver | Forced-step direction state compares the forced pitch with itself | High | Fixed state update order |
| Reproducibility | Global random state is mixed with model construction | Medium | Injected seeded RNG |
| Duration | README's 60-second claim is not guaranteed by note timing | Medium | Report actual duration |
| Validation | No tests/package metadata | High | Added pytest + pyproject |

## What remains research-grade

- The chord corpus is still a tiny hand-authored corpus; it is not a representative learned harmonic model.
- The vortex mapping is a computational metaphor, not a validated aerodynamic-to-musical physical model.
- The renderer is additive synthesis, not a trained neural vocoder.
- Musical quality metrics such as key correlation should be treated as diagnostics, not objective proof of musicality.

## Recommended production evolution

1. Add a real symbolic dataset and train a sequence model.
2. Add rhythm/event prediction independently from pitch prediction.
3. Add phrase/form state (A/B/C sections, cadence targets, motif memory).
4. Add MIDI Standard MIDI File export.
5. Add offline batch generation and regression fixtures.
6. Add oversampled/anti-aliased oscillator paths if extending the synth to bright harmonic spectra.
7. Add golden WAV spectral tests only after renderer behavior is deliberately frozen.
