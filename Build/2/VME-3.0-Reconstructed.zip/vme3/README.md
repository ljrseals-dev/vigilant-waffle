# Vortex Music Engine 3.0

Reconstructed VME 3.0 core based on the established VME 2.0 behavioral contract. The design keeps the interpretable Vortex/PST/Downwash pipeline authoritative and treats GRU/Transformer priors as optional proposal modules.

## Install

```bash
pip install -e .
```

No third-party dependency is required for procedural generation, WAV, MIDI, or metrics. PyTorch can be added independently for learned priors.

## Run

```bash
python vme_cli.py --prior procedural --seed 42 --notes 160 --wav output.wav --midi output.mid --metrics metrics.json
python benchmark.py
```

## Architecture

`VortexDynamics -> candidate generation -> hard constraints -> neural/PST/vortex scoring -> Downwash resolution -> NoteEvent`

Temperature controls stochastic selection; `0` is deterministic. Hard constraints are applied before sampling.

## Important reconstruction qualification

This is a behavioral/architectural reconstruction, not byte-for-byte compatibility with an unavailable original archive. The reported VME 2.0 metrics are retained as regression references, not asserted as reproduced measurements until the original fixture corpus is available.
