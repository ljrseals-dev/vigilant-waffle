from dataclasses import dataclass
@dataclass(frozen=True)
class NoteEvent: pitch:int; velocity:int; duration:float; chord:str; time:float
class Generator:
    def __init__(self,prior,vortex,resolver,seed=42,temperature=0): self.prior=prior; self.vortex=vortex; self.resolver=resolver; self.temperature=temperature
    def generate(self,n_notes=160):
        out=[]; pitches=[]; t=0
        for _ in range(n_notes):
            raw=self.vortex.next_pitch(); chord=self.resolver.maybe_change_chord(); prior=self.prior.logits(pitches,{'raw_pitch':raw,'chord':chord,'vortex':self.vortex.state})
            pitch=self.resolver.resolve(raw,self.temperature,prior); pitches.append(pitch); self.vortex.observe(pitches)
            dur=.5; vel=int(68+22*self.vortex.state.energy); out.append(NoteEvent(pitch,vel,dur,chord,t)); t+=dur
        return out
