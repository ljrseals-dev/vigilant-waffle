import random
from .core import VortexDynamics
from .pst import HarmonicMemory
from .neural import NullPrior,GRUPrior,TransformerPrior
from .resolver import DownwashResolver,ScoreWeights
from .generation import Generator
class VME:
    def __init__(self,prior='procedural',temperature=0.0,seed=42,low=48,high=84):
        self.seed=seed; self.rng=random.Random(seed); self.vortex=VortexDynamics(self.rng,low,high); self.pst=HarmonicMemory(); self.resolver=DownwashResolver(self.pst,self.rng,ScoreWeights()); self.prior=self._create_prior(prior); self.generator=Generator(self.prior,self.vortex,self.resolver,seed,temperature)
    def _create_prior(self,name):
        if hasattr(name,'logits'): return name
        return {'gru':GRUPrior,'transformer':TransformerPrior}.get(name,NullPrior)()
    def train_pst(self,sequences): self.pst.train(sequences)
    def generate(self,n_notes=160): return self.generator.generate(n_notes)
